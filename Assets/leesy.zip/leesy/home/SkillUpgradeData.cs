using System.Collections.Generic;
using UnityEngine;

namespace Lsy
{
    
    //   nodes[0]: skillId="tracking",  skillName="������",  price=1000, requiredNpcLevel=1
    //   nodes[1]: skillId="disguise",  skillName="�����",  price=2000, requiredNpcLevel=1
    //   nodes[2]: skillId="sabotage",  skillName="���ذ���", price=3000, requiredNpcLevel=2
    //   nodes[3]: skillId="ambush",    skillName="�ź�",    price=4000, requiredNpcLevel=2

    [CreateAssetMenu(fileName = "SkillUpgradeData", menuName = "Upgrade/SkillUpgradeData")]
    public class SkillUpgradeData : ScriptableObject
    {
        public string groupName;

        public List<SkillUpgradeNode> nodes = new List<SkillUpgradeNode>();
    }

    [System.Serializable]
    public class SkillUpgradeNode
    {
        public string skillId;
        public string skillName;

        public int price;
        public int requiredNpcLevel;
    }
}