using System.Collections.Generic;
using UnityEngine;

namespace Lsy
{
    public abstract class BaseUpgradeRow : MonoBehaviour
    {
        [Header("��� ��ư�� (������� ����)")]
        public List<UpgradeNode> upgradeNodes = new List<UpgradeNode>();

        public void RefreshNodes(int npcLevel, CharacterUnit unit)
        {
            Debug.Log($"<color=yellow>[UpgradeRow] {gameObject.name} RefreshNodes ȣ�� - ��� ��:{upgradeNodes.Count}, NPC Lv:{npcLevel}</color>");

            for (int i = 0; i < upgradeNodes.Count; i++)
            {
                if (upgradeNodes[i] == null)
                {
                    Debug.LogWarning($"[UpgradeRow] upgradeNodes[{i}]�� NULL - �ν����Ϳ��� ������ Ȯ���ϼ���.");
                    continue;
                }

                bool canUpgrade = CanPurchaseNode(i, npcLevel, unit);
                int price = GetNodePrice(i);

                Debug.Log($"<color=yellow>[UpgradeRow] ���[{i}] canUpgrade:{canUpgrade}, price:{price}</color>");

                upgradeNodes[i].SetNodeState(canUpgrade, price);

                int capturedIndex = i;
                upgradeNodes[i].nodeButton.onClick.RemoveAllListeners();
                upgradeNodes[i].nodeButton.onClick.AddListener(() => OnNodeClicked(capturedIndex));
            }
        }

        protected abstract bool CanPurchaseNode(int nodeIndex, int npcLevel, CharacterUnit unit);
        protected abstract void OnNodeClicked(int nodeIndex);
        protected virtual int GetNodePrice(int nodeIndex) => 0;

        protected CharacterShop GetLocalShop()
        {
            if (PlayerAccount.LocalInstance == null)
            {
                Debug.LogWarning("[UpgradeRow] PlayerAccount.LocalInstance�� NULL");
                return null;
            }
            if (PlayerAccount.LocalInstance.currentSelectedCharacter == null)
            {
                Debug.LogWarning("[UpgradeRow] currentSelectedCharacter�� NULL");
                return null;
            }

            CharacterShop shop = PlayerAccount.LocalInstance.currentSelectedCharacter
                .GetComponent<CharacterShop>();

            if (shop == null)
                Debug.LogError("[UpgradeRow] CharacterShop ������Ʈ�� �����տ� �����ϴ�!");

            return shop;
        }

        protected NPCState GetNpcState()
        {
            BaseUpgradeUI parentUI = GetComponentInParent<BaseUpgradeUI>();
            if (parentUI == null)
            {
                Debug.LogWarning($"[UpgradeRow] {gameObject.name}�� �θ𿡼� BaseUpgradeUI�� ã�� ���߽��ϴ�. ���̾��Ű ������ Ȯ���ϼ���.");
                return null;
            }
            if (parentUI.NpcState == null)
            {
                Debug.LogWarning("[UpgradeRow] BaseUpgradeUI�� ã������ NpcState�� NULL");
                return null;
            }
            return parentUI.NpcState;
        }
    }
}