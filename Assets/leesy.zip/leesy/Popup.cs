using UnityEngine;

namespace Lsy
{
    public class Popup : MonoBehaviour
    {
        //����Ʈ �˾� ���� ����, ����Ʈ �߰� �ڵ�
        [SerializeField] private GameObject _popup;

        public void OpenPopup()
        {
            PopupManager.Instance.ToggleObjectPopup(_popup, true);
        }

        public void ClosePopup()
        {
            PopupManager.Instance.ToggleObjectPopup(_popup, false);
        }

    }
}

